## ---- eval=FALSE---------------------------------------------------------
#  check_inputs = function(data, sets, ncomps, center, scale) {
#    if (!is.matrix(data) &
#        !is.data.frame(data) ) {
#      stop("'data' must be a matrix or data.frame containing the data set")
#    }
#  ...
#  }

## ---- eval=FALSE---------------------------------------------------------
#  for (k in 1:length(xTables)) {
#      val = svd(xTables[[k]])
#      alpha[[k]] = (val$d[1]^-2)
#      aVector = c(aVector, rep(alpha[[k]], ncol(val$u)) )
#    }

## ---- eval=FALSE---------------------------------------------------------
#    nObs = nrow(xTables[[1]])
#    m = rep(1/nObs, nObs)

## ---- eval=FALSE---------------------------------------------------------
#    # X = P \Delta Q^T
#    xTilde = diag(m^(1/2)) %*% X %*% diag(aVector^(1/2))  # \tilde{X} = M^{1/2} A W^{1/2}
#    xDecomp = svd(xTilde)  # \tilde{A} = P \Delta Q^T
#    eigenvalues = (xDecomp$d)^2
#  
#    P = diag(m^(-1/2)) %*% xDecomp$u
#    Q = diag(aVector^(-1/2)) %*% xDecomp$v

## ---- eval=FALSE---------------------------------------------------------
#  Summary of Multiple Factor Analysis (mfa) object:
#  
#  This object contains information on the data inputs as well as on the analysis outputs.
#  You can access the full contents of any of these components using name_mfaObject$component_name.
#  For example, if you are interested in viewing the eigenvalues for an mfa object called 'x', you would type 'x$eigenvalues'.
#  
#  Your MFA object contains the following items :
#  ################################################################################
#             Component Name    ::    Description
#  ################################################################################
#                       data    ::    raw data input by user
#                       sets    ::    number of active variables across all the tables
#                     ncomps    ::    number of factors computed in the analysis
#                     center    ::    whether centering was performed on the data
#                      scale    ::    whether scaling was performed on the data
#                eigenvalues    ::    eigenvalues
#               factorScores    ::    common factor scores
#                      alpha    ::    table weights
#                    aVector    ::    vector of alphas
#        partialFactorScores    ::    partial factor scores
#             loadingByTable    ::    variable loadings (list form)
#             matrixLoadings    ::    variable loadings (matrix form)
#                          X    ::    the processed concatenated data table
#  ################################################################################
#  
#  Number of tables considered in this multiple factor analysis: 10
#  Number of active variables: 53
#  Maximum Eigenvalue: 0.7702551
#  Common factor scores for first two components:
#           Dim1    Dim2
#      1 : -0.98 : +0.16
#      2 : -0.81 : +0.03
#      3 : -0.76 : -0.45
#      4 : -1.11 : -0.17
#      5 : +1.37 : -0.13
#      6 : +1.26 : -0.11
#      7 : +0.81 : +0.20
#      8 : +0.93 : +0.41
#      9 : -0.67 : +0.37
#     10 : +0.07 : -0.76
#     11 : -0.48 : +0.51
#     12 : +0.37 : -0.08
#  
#  ################################################################################

## ---- eval=FALSE---------------------------------------------------------
#  ################################################################################
#  
#  Variable loadings:
#  ################################################################################
#  If you would like to see variable loadings for a single table,
#    enter the corresponding table number (1 through 10).
#   To see variable
#    loadings for all tables, type ALL.
#   To skip seeing any variable loadings, type NONE (case-sensitive), or Return.1
#  Loadings for the first two components, showing table 1 of 10:
#           Dim1    Dim2
#     V1 : -0.29 : +0.32
#     V2 : -0.27 : -0.25
#     V3 : -0.26 : +0.40
#     V4 : +0.24 : -0.18
#     V5 : +0.29 : +0.16
#     V6 : -0.23 : +0.13

## ---- echo=TRUE----------------------------------------------------------
library(MFA)

d <- loadWineData()
# also get some information on the wine data set such as wine names (obsnames) and variable names
varlabels <- loadWineInfo()$varkeys
obslabels <- loadWineInfo()$obskeys
obscolors <- loadWineInfo()$colors

s = list(  seq(2,7), seq(8,13), seq(14,19), seq(20,24),
           seq(25,30), seq(31,35), seq(36,39), seq(40,45),
           seq(46,50), seq(51,54) )
a = mfa(d, s)

## ---- fig.cap="Compromise or common factor scores of the wine data set", fig.show='hold', fig.width=4, fig.height=4,echo=TRUE----
plot_compromise(a, obsnames = obslabels, textcolor = obscolors, 
                cexmain=0.9, cexaxis=0.6, cexlab=0.8, sz=0.8 )

## ---- fig.cap="Partial factor scores for assessors 2 and 4", fig.show='hold', fig.width=7, fig.height=4, echo=TRUE----
par(mfrow=c(1,2))
plot_partial_fac(a, table = 2, obsnames = obslabels, textcolor = obscolors,
                 cexmain=0.9, cexaxis=0.6, cexlab=0.8, sz=0.8 )
plot_partial_fac(a, table = 4, obsnames = obslabels, textcolor = obscolors,
                 cexmain=0.9, cexaxis=0.6, cexlab=0.8, sz=0.8 )

## ---- fig.cap="Variable loadings for assessors 2 and 4", fig.show='hold',  fig.width=7, fig.height=4, echo=TRUE----
par(mfrow=c(1,2))
plot_loading(a, varnames = varlabels, table = 2, 
             cexmain=0.9, cexaxis=0.6, cexlab=0.8, sz=0.8 )
plot_loading(a, varnames = varlabels, table = 4, 
             cexmain=0.9, cexaxis=0.6, cexlab=0.8, sz=0.8 )

## ---- fig.cap="Variable loadings for assessors 2 and 4", fig.show='hold',  fig.width=7, fig.height=4, echo=TRUE----

par(mfrow=c(1,2))
plot_biplot(a, obsnames = obslabels, varnames = varlabels, table=2,
             cexmain=0.8, cexaxis=0.6, cexlab=0.8, sz=0.8,
             cexlegend = 0.6)
plot_biplot(a, obsnames = obslabels, varnames = varlabels, table=4,
             cexmain=0.8, cexaxis=0.6, cexlab=0.8, sz=0.8,
             cexlegend = 0.6)

## ---- fig.cap="Eigenvalue magnitudes from mfa on the wine data set", fig.show='hold', fig.width=4, fig.height=4, echo=TRUE----
plot_ev(a)

## ---- fig.cap="Percent inertia contribution of each component in the wine data mfa", fig.show='hold', fig.width=4, fig.height=4, echo=TRUE----
plot_inertia_pie(a, radius=1, cexlab=0.7)

## ------------------------------------------------------------------------
table<-obs_dim(a)

rownames(table) <- c('NZ1','NZ2','NZ3','NZ4',
               'FR1','FR2','FR3','FR4',
               'CA1','CA2','CA3','CA4')

colnames(table) <- c('dim1','dim2','dim3','dim4',
               'dim5','dim6','dim7','dim8',
               'dim9','dim10','dim11','dim12')

knitr::kable(table[,1:4])


## ------------------------------------------------------------------------
table<-table_dim(a)

rownames(table) <- c('Assessor 1','Assessor 2','Assessor 3','Assessor 4',
               'Assessor 5','Assessor 6','Assessor 7','Assessor 8',
               'Assessor 9','Assessor 10')

colnames(table) <- c('dim1','dim2','dim3','dim4',
               'dim5','dim6','dim7','dim8',
               'dim9','dim10','dim11','dim12')

knitr::kable(table[,1:4])


## ------------------------------------------------------------------------

table<-eigenvalueTable(a)
colnames(table) <- c('dim1','dim2','dim3','dim4',
               'dim5','dim6','dim7','dim8',
               'dim9','dim10','dim11','dim12')

knitr::kable(table[,1:4])


## ------------------------------------------------------------------------

table1 = d[,seq(2,7)]
table2 = d[,seq(8,13)]
lg(table1,table2)


## ------------------------------------------------------------------------
table<-lg_table(d,s)
rownames(table) <- c('Table1','Table2','Table3','Table4',
               'Table5','Table6','Table7','Table8',
               'Table9','Table10')

colnames(table) <- c('Table 1','Table 2','Table 3','Table 4',
               'Table 5','Table 6','Table 7','Table 8',
               'Table 9','Table 10')

knitr::kable(table)

## ------------------------------------------------------------------------
boot<-bootstrap_factorscores(a)
table<-boot$Tstar
rownames(table) <- c('NZ1','NZ2','NZ3','NZ4',
               'FR1','FR2','FR3','FR4',
               'CA1','CA2','CA3','CA4')

colnames(table) <- c('dim1','dim2','dim3','dim4',
               'dim5','dim6','dim7','dim8',
               'dim9','dim10','dim11','dim12')

knitr::kable(table[,1:4])

## ---- eval=FALSE---------------------------------------------------------
#  mfa_obj <- a #name needed for app
#  active_var_names <- loadWineInfo()$varkeys #name needed for app
#  active_obs_names <- loadWineInfo()$obskeys #name needed for app
#  active_col_vec <- loadWineInfo()$colors #name needed for app
#  MFA::runExample()

## ---- eval=FALSE---------------------------------------------------------
#  # create a data set of random integers ranging from 50 to 100
#  nrows=14 #number of observations (like the wines)
#  nvars=33 #number of vars
#  # fill data with random integers between 50 and 100
#  d2 <- replicate( nvars, sample( 50:100, size=nrows, rep=TRUE ) )
#  # sets -- indexing into d2, so should cover range 1:nvars
#  s2 <- list( seq(1,4), seq(5,10), seq(11,19), seq(20,22),
#              seq(23,30), seq(31,33) )
#  # create the mfa object with the random dataset
#  a2 <- mfa( d2, s2 )
#  # test run app with a2 object
#  mfa_obj <- a2 #name needed for app
#  active_var_names <- NULL #clear previous values so defaults will be used
#  active_obs_names <- NULL #clear previous values so defaults will be used
#  active_col_vec <- NULL #clear previous values so defaults will be used
#  # run the app
#  MFA::runExample()

